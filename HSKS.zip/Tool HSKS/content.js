const STATUS_KEY = 'isEnabled';
const DATA_KEY = 'csvData';
const PERSON_KEY = 'selectedPersonName';
const USE_MANUAL_KEY = 'useManualData';
const MANUAL_DATA_KEY = 'manualCsvString';

let isEnabled = false;
let csvData = null; 
let selectedPerson = null; 
let activeInputElement = null;
let currentActiveData = null;

// --- 1. Core Functions ---

function parseCSV(text) {
    const [headerLine, ...lines] = text.trim().split(/\r?\n/);
    const headers = headerLine.split(";").map(h => h.trim());
    const data = lines.map(line => {
        const values = line.split(";").map(v => v.trim());
        return Object.fromEntries(headers.map((h, i) => [h, values[i] || ""]));
    });
    return { headers, data };
}

function dispatchChangeEvent(element) {
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.dispatchEvent(new Event('blur', { bubbles: true }));
}

function updateContentState(result) {
    isEnabled = result[STATUS_KEY] || false;
    csvData = result[DATA_KEY] || null;
    const selectedPersonName = result[PERSON_KEY] || "";
    const useManual = result[USE_MANUAL_KEY] || false;
    const manualCsvString = result[MANUAL_DATA_KEY] || "";

    selectedPerson = null;
    currentActiveData = null;

    if (useManual) {
        try {
            const manualParsed = parseCSV(manualCsvString);
            if (manualParsed.data.length > 0) {
                currentActiveData = {
                    headers: manualParsed.headers,
                    row: manualParsed.data[0]
                };
            }
        } catch (e) {
            console.error("Lỗi parse dữ liệu thủ công:", e);
        }
    } else {
        if (csvData && csvData.data && selectedPersonName) {
            selectedPerson = csvData.data.find(row => row[csvData.headers[0]] === selectedPersonName);
            if (selectedPerson) {
                currentActiveData = {
                    headers: csvData.headers,
                    row: selectedPerson
                };
            }
        }
    }

    document.querySelectorAll(".csv-data-picker-popup").forEach(p => p.remove());
}

// --- 2. Data Loading & Event Listeners ---

chrome.storage.local.get(
    [STATUS_KEY, DATA_KEY, PERSON_KEY, USE_MANUAL_KEY, MANUAL_DATA_KEY],
    updateContentState
);

chrome.storage.onChanged.addListener((changes, namespace) => {
    if (
        namespace === 'local' &&
        (changes[STATUS_KEY] ||
         changes[DATA_KEY] ||
         changes[PERSON_KEY] ||
         changes[USE_MANUAL_KEY] ||
         changes[MANUAL_DATA_KEY])
    ) {
        chrome.storage.local.get(
            [STATUS_KEY, DATA_KEY, PERSON_KEY, USE_MANUAL_KEY, MANUAL_DATA_KEY],
            updateContentState
        );
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "USE_MANUAL_DATA" || request.action === "SELECT_PERSON") {
        chrome.storage.local.get(
            [STATUS_KEY, DATA_KEY, PERSON_KEY, USE_MANUAL_KEY, MANUAL_DATA_KEY],
            updateContentState
        );
    }
});

// --- 3. Popup Creation ---

function createDataPopup(el) {
    if (!currentActiveData) return;

    document.querySelectorAll(".csv-data-picker-popup").forEach(p => p.remove());

    const rect = el.getBoundingClientRect();
    const popup = document.createElement("div");
    popup.className = "csv-data-picker-popup";
    
    popup.style = `
        position:absolute;
        background:white;
        border:1px solid #ccc;
        border-radius:6px;
        padding:6px;
        z-index:99999999;
        box-shadow:0 2px 10px rgba(0,0,0,0.2);
        top:${rect.bottom + window.scrollY + 5}px;
        left:${rect.left + window.scrollX}px;
        max-height:250px;
        overflow-y:auto;
        font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        font-size:13px;
        min-width:${rect.width}px;
    `;

    const table = document.createElement("table");
    table.style = "border-collapse:collapse;width:100%;";
    
    const headerRow = table.insertRow();
    const firstHeader = currentActiveData.headers[0];
    headerRow.innerHTML = `
        <th style="text-align:left;border-bottom:1px solid #ddd;padding:4px;">${firstHeader}</th>
        <th style="text-align:left;border-bottom:1px solid #ddd;padding:4px;">Giá trị</th>
    `;

    currentActiveData.headers.slice(1).forEach(key => {
        const value = currentActiveData.row[key] || '';
        const row = table.insertRow();
        row.style.cursor = 'pointer';
        
        const keyCell = row.insertCell();
        keyCell.innerHTML = key;
        keyCell.style.padding = '4px 6px';

        const valueCell = row.insertCell();
        valueCell.innerHTML = value;
        valueCell.style.padding = '4px 6px';

        row.addEventListener('mouseenter', () => row.style.background = '#f0f0f0');
        row.addEventListener('mouseleave', () => row.style.background = 'white');

        row.addEventListener('click', () => {
            if (activeInputElement) {
                activeInputElement.value = value;
                dispatchChangeEvent(activeInputElement);
                activeInputElement.focus();
            }
            popup.remove();
        });
    });

    popup.appendChild(table);
    document.body.appendChild(popup);
}

// --- 4. Event Listeners for Webpage ---

// Lưu input đang hoạt động
document.addEventListener("focusin", e => {
    const el = e.target;
    activeInputElement = ["INPUT", "TEXTAREA"].includes(el.tagName) ? el : null;
});

// Khi click vào input => hiện popup
document.addEventListener("click", e => {
    const el = e.target;
    const isInput = ["INPUT", "TEXTAREA"].includes(el.tagName);

    if (isEnabled && isInput && currentActiveData) {
        activeInputElement = el;
        createDataPopup(el);
    } else if (!e.target.closest(".csv-data-picker-popup")) {
        document.querySelectorAll(".csv-data-picker-popup").forEach(p => p.remove());
    }
});
