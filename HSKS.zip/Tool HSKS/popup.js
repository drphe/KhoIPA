const STATUS_KEY = 'isEnabled';
const DATA_KEY = 'csvData';
const PERSON_KEY = 'selectedPersonName';
// KHÓA MỚI
const MANUAL_DATA_KEY = 'manualCsvString';
const USE_MANUAL_KEY = 'useManualData';

const statusEl = document.getElementById('status');
const toggleBtn = document.getElementById('toggleBtn');
const csvFile = document.getElementById('csvFile');
const importBtn = document.getElementById('importBtn');
const personSelect = document.getElementById('personSelect');

// ELEMENTS MỚI
const manualCsvInput = document.getElementById('manualCsvInput');
const saveManualBtn = document.getElementById('saveManualBtn');
const useManualCheckbox = document.getElementById('useManualData');
const messageEl = document.getElementById('message');

// --- 1. Message Function (Giữ nguyên) ---

function showMessage(text, type = 'info') {
    messageEl.textContent = text;
    messageEl.className = type;
    messageEl.style.display = 'block';
    
    setTimeout(() => {
        messageEl.style.display = 'none';
        messageEl.textContent = '';
    }, 3000);
}

// --- 2. Core Functions (Giữ nguyên Parse CSV) ---// thay ; bằng , tùy file csv

function parseCSV(text) {
    const [headerLine, ...lines] = text.trim().split(/\r?\n/);
    const headers = headerLine.split(";").map(h => h.trim());
    const data = lines.map(line => {
        const values = line.split(";").map(v => v.trim());
        return Object.fromEntries(headers.map((h, i) => [h, values[i] || ""]));
    });
    return { headers, data };
}

// --- 3. Update UI (Đã sửa để quản lý 2 chế độ) ---

function updateUI(isEnabled, csvData, selectedPersonName, manualCsvString, useManual) {
    statusEl.textContent = isEnabled ? "Tính năng: Đang BẬT" : "Tính năng: Đang TẮT";
    toggleBtn.textContent = isEnabled ? "Tắt Tính Năng" : "Bật Tính Năng";
    toggleBtn.style.backgroundColor = isEnabled ? '#dc3545' : '#28a745';
    toggleBtn.style.color = 'white';
    
    // Cập nhật giá trị và trạng thái checkbox
    manualCsvInput.value = manualCsvString || '';
    useManualCheckbox.checked = useManual;

    // QUẢN LÝ HIỂN THỊ DỰA TRÊN CHECKBOX
    if (useManual) {
        // Chế độ thủ công: Ẩn dropdown chọn người
        personSelect.style.display = 'none';
        
        // Gửi dữ liệu thủ công cho Content Script
        const manualData = manualCsvString ? parseCSV(manualCsvString) : null;
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                action: "USE_MANUAL_DATA", 
                manualData: manualData 
            });
        });
        
    } else {
        // Chế độ Import: Hiện dropdown nếu có dữ liệu
        if (csvData && csvData.data && csvData.data.length > 0) {
            personSelect.style.display = 'block';
            let options = `<option value="">-- Chọn tên người --</option>`;
            options += csvData.data.map(row => 
                `<option value="${row[csvData.headers[0]]}" ${row[csvData.headers[0]] === selectedPersonName ? 'selected' : ''}>
                    ${row[csvData.headers[0]]}
                </option>`
            ).join("");
            personSelect.innerHTML = options;
        } else {
            personSelect.style.display = 'none';
            personSelect.innerHTML = '<option value="">Chưa có dữ liệu CSV</option>';
        }
        
        // Đảm bảo gửi người được chọn (nếu có)
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                action: "SELECT_PERSON", 
                selectedName: selectedPersonName 
            });
        });
    }
}

// --- 4. Initial Load (Đã sửa) ---

// Tải tất cả 5 khóa dữ liệu
chrome.storage.local.get([STATUS_KEY, DATA_KEY, PERSON_KEY, MANUAL_DATA_KEY, USE_MANUAL_KEY], (result) => {
    updateUI(
        result[STATUS_KEY], 
        result[DATA_KEY], 
        result[PERSON_KEY], 
        result[MANUAL_DATA_KEY], 
        result[USE_MANUAL_KEY] || false // Mặc định là false
    );
});

// --- 5. Event Listeners (Đã sửa) ---

toggleBtn.onclick = () => {
    chrome.storage.local.get([STATUS_KEY, DATA_KEY, PERSON_KEY, MANUAL_DATA_KEY, USE_MANUAL_KEY], (result) => {
        const newStatus = !result[STATUS_KEY];
        chrome.storage.local.set({ [STATUS_KEY]: newStatus }, () => {
            updateUI(newStatus, result[DATA_KEY], result[PERSON_KEY], result[MANUAL_DATA_KEY], result[USE_MANUAL_KEY] || false); 
            showMessage(newStatus ? "✅ Tính năng đã được BẬT." : "❌ Tính năng đã được TẮT.", newStatus ? 'success' : 'info');
            chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                chrome.tabs.sendMessage(tabs[0].id, {action: "TOGGLE_STATE", isEnabled: newStatus});
            });
        });
    });
};

importBtn.onclick = () => { csvFile.click(); };
csvFile.onchange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
        const csvData = parseCSV(event.target.result);
        if (csvData.data.length > 0) {
            const newSelectedName = ""; 
            // Lưu dữ liệu Import, BẬT tính năng, và TẮT chế độ thủ công
            chrome.storage.local.set({ [DATA_KEY]: csvData, [PERSON_KEY]: newSelectedName, [STATUS_KEY]: true, [USE_MANUAL_KEY]: false }, () => {
                showMessage("✅ Tải CSV thành công! Đã chuyển sang chế độ Import.", 'success');
                // Tải lại UI
                updateUI(true, csvData, newSelectedName, manualCsvInput.value, false); 
            });
        } else {
            showMessage("❌ File CSV không có dữ liệu!", 'info');
        }
    };
    reader.readAsText(file, "UTF-8"); 
};

personSelect.onchange = (e) => {
    const selectedName = e.target.value;
    chrome.storage.local.get([STATUS_KEY, DATA_KEY, MANUAL_DATA_KEY, USE_MANUAL_KEY], (result) => {
        chrome.storage.local.set({ [PERSON_KEY]: selectedName }, () => {
            updateUI(result[STATUS_KEY], result[DATA_KEY], selectedName, result[MANUAL_DATA_KEY], result[USE_MANUAL_KEY] || false);
            if(selectedName) {
                showMessage("Đã chọn tên người: " + selectedName, 'info');
            } else {
                showMessage("Đã hủy chọn người.", 'info');
            }
        });
    });
};

// LISTENERS MỚI

useManualCheckbox.onchange = (e) => {
    const useManual = e.target.checked;
    chrome.storage.local.get([STATUS_KEY, DATA_KEY, PERSON_KEY, MANUAL_DATA_KEY], (result) => {
        // Lưu trạng thái checkbox
        chrome.storage.local.set({ [USE_MANUAL_KEY]: useManual }, () => {
            updateUI(result[STATUS_KEY], result[DATA_KEY], result[PERSON_KEY], result[MANUAL_DATA_KEY], useManual);
            showMessage(useManual ? "Đã chuyển sang chế độ Thủ công." : "Đã chuyển sang chế độ Import.", 'info');
        });
    });
};

saveManualBtn.onclick = () => {
    const manualString = manualCsvInput.value;
    
    try {
        const parsedData = parseCSV(manualString);
        if (parsedData.headers.length < 2 || parsedData.data.length === 0) {
             throw new Error("Dữ liệu không hợp lệ");
        }
        
        // Lưu chuỗi CSV thô
        chrome.storage.local.set({ [MANUAL_DATA_KEY]: manualString }, () => {
            showMessage("✅ Đã lưu dữ liệu thủ công thành công!", 'success');
            
            // Nếu đang ở chế độ thủ công, cần cập nhật content script
            if(useManualCheckbox.checked) {
                chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        action: "USE_MANUAL_DATA", 
                        manualData: parsedData // Gửi dữ liệu đã parse đi
                    });
                });
            }
        });
        
    } catch(e) {
        showMessage("❌ Lỗi: Dữ liệu CSV không hợp lệ. Phải có ít nhất 2 cột (key;value).", 'info');
    }
};